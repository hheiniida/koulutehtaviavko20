package vk6.java;

import java.util.Scanner;

public class Palkkalaskuri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner lukija = new Scanner(System.in);

		
	int tunnit;
	double tuntipalkka;
	int paivat=0;	
	
	
	
		
	System.out.print("Anna tuntipalkkasi: ");
	tuntipalkka = lukija.nextInt();
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		System.out.print("Tunteja yhteens�: ");
		System.out.print("Bruttopalkkasi: ");
		System.out.print("Annoit tunnit: ");
	}

}
