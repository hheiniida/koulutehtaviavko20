package vk1ja2;

public class Eka {

	public static void main(String[] args) {
		// Tulostetaan Moi
System.out.println("Moi");
	}

}
