package vk1ja2;

import java.util.Scanner;

public class Elokuvalippu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
	double lippu;
	double pakkaus = 35;
		
	lippu = pakkaus/5;
	System.out.println("Yhden lipun hinta: "+ lippu);
	}

}
