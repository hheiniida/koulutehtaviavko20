package vk5.java;

import java.util.Scanner;

public class OsoiteTarra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner lukija = new Scanner(System.in);
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
