package vk1ja2;
/**
 * 
 * @author Heini Haatanen
 * 
 *
 */
public class Puoluetuki {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int edustajat = 39;
		int puoluetuki;
		int tukiPerHnkl = 180000;
		
		puoluetuki = edustajat * tukiPerHnkl;
		System.out.println("Puoluetuki m��r� vuodessa: "+puoluetuki);
		
	}

}
